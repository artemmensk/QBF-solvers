let version = "1.8.2"
let date = "Fri 28 Nov 2014 18:53:23 GMT"
