let version = "1.8.8"
let date = "Thu  5 Jul 2018 09:34:46 BST"
