/* includes $CAMLLIB/caml/config.h */
#include <caml/config.h>
