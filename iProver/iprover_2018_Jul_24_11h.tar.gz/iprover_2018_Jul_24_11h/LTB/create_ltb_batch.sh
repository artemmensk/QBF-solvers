#!/bin/bash
#creates batch file
#note OutDir should exist

#create_ltb_batch.sh Header Tail FileList OutDir

# if OutDir does not exists then it is created

#create_ltb_batch.sh MZR.header MZR_bushy_rand_100_list /shareddata/korovin/LTB_2012/MZR_bushy_rand_100_list/


Header=$1
FileList=$2
OutDir=$3

if [ ! -d "$OutDir" ]; then
mkdir "$OutDir"
fi

PairList=$(cat $FileList | sed "s|^\(.*/\)\([^/]*\)$|\1\2 "$OutDir"\2|")

#echo "-----------PairList-------"
#echo "$PairList"

cat "$Header"
echo "$PairList"
echo "% SZS end BatchProblems"
